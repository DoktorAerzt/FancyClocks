package de.empty2k12.fancyclocks.common.misc;

public class ModInfo {
	
	public static final String MOD_NAME = "Fancy Clocks";
	public static final String MOD_ID = "fancyclocks";
	
	public static final String COMMON_PROXY = "de.empty2k12.fancyclocks.common.proxy.CommonProxy";
	public static final String CLIENT_PROXY = "de.empty2k12.fancyclocks.client.ClientProxy";

}
