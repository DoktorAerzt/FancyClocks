package de.empty2k12.fancyclocks.common.proxy;

public class CommonProxy {
	
	public void registerRenderers() {
		
	}

}
