package de.empty2k12.fancyclocks.api;

import net.minecraft.entity.player.EntityPlayer;

public interface IClockScrewdriver {
	
	/*
	 * 
	 * 
	 * */
	
}
